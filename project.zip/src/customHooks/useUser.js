import { addDoc, collection, doc, updateDoc } from "firebase/firestore";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { db } from "../firebase";

export const useUser = (eventData) => {
  const { currentUser } = useSelector((state) => state.user);
  const [addSucess, setAddSucess] = useState(false);
  const [updateSucess, setUpdateSucess] = useState(false);
  // useEffect(() => console.log(currentUser.uid), []);

  const createUser = async (data) => {
    try {
      await addDoc(collection(db, "users"), {
        name: data.name,
        interests: data.interests || [],
        bucketList: data.bucketList || [],
      });
      console.log("added success");
      setAddSucess(true);
    } catch (error) {
      console.log({ addUserError: error.message });
    }
  };
  const updateUser = async (id, data) => {
    try {
      const userDoc = doc(db, "events", id);
      await updateDoc(userDoc, data);
      console.log("updated successfully");
      setUpdateSucess(true);
    } catch (error) {
      console.log({ updateUserError: error.message });
    }
  };

  return {
    createUser,
    updateUser,
    updateSucess,
    addSucess,
  };
};
