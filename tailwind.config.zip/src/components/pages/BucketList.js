import React, { useEffect } from "react";
import { getDatabase, ref, child, get, onValue } from "firebase/database";

export const BucketList = () => {
  useEffect(() => {
    // const db = getDatabase();
    // const starCountRef = ref(db, "users/");
    // onValue(starCountRef, (snapshot) => {
    //   console.log(snapshot.val());
    // const data = snapshot.val();
    // updateStarCount(postElement, data);
    // });
  }, []);

  return <div>BucketList</div>;
};
