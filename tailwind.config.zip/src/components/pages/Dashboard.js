import {
  collection,
  getDocs,
  onSnapshot,
  orderBy,
  query,
} from "firebase/firestore";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { db } from "../../firebase";
import { AddEditEvent } from "../AddEditEvent";
import { BucketList } from "./BucketList";
import UpcomingEvents from "./UpcomingEvents";

const Dashboard = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [events, setEvents] = useState([]);

  const eventCollectionRef = collection(db, "events");
  const { currentUser } = useSelector((state) => state.user);
  const getEvents = async () => {
    const data = await getDocs(eventCollectionRef);
    // const data = await getDocs(collection(db, "user"));
    const eventsArray = data.docs.map((doc) => ({
      ...doc.data(),
      id: doc.id,
    }));

    setEvents(eventsArray);
  };
  useEffect(() => {
    if (!currentUser) {
      navigate("/login");
    } else {
      try {
        getEvents();
      } catch (error) {
        console.log({ ErrorInFetchingEvents: error.message });
      }
    }
  }, [currentUser]);

  return !currentUser ? (
    <div>Unathorised</div>
  ) : (
    <div className="min-h-screen bg-[#81d4fa]">
      <h3>Hii Welcome to our site!</h3>
      <button className="bg-blue-600" onClick={getEvents}>
        Refresh
      </button>
      <br />
      <div>
        <AddEditEvent>
          <button
            className="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
            type="button"
          >
            Add an Event
          </button>
        </AddEditEvent>
      </div>
      <div className="flex flex-col space-y-2 md:flex">
        <UpcomingEvents events={events} />
        <BucketList />
      </div>
      {/* <div className="m-auto border-1 p-3 flex flex-col">
        {events.length === 0 ? (
          <div>no events to show</div>
        ) : (
          events.map((e) => {
            return <EventCard details={e} />;
          })
        )}
      </div> */}
    </div>
  );
};

export default Dashboard;
